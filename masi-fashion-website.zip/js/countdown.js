/**
 * MASI FASHION — COUNTDOWN TIMER MODULE
 * Drives the "Exclusive Offers" countdown blocks. Each [data-countdown]
 * element counts down to a target Date set via its data-deadline attribute
 * (ISO string), or defaults to 5 days from first page load.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', initCountdowns);

  function initCountdowns() {
    var countdowns = document.querySelectorAll('[data-countdown]');
    if (!countdowns.length) return;

    countdowns.forEach(function (el) {
      var deadlineAttr = el.getAttribute('data-deadline');
      var deadline = deadlineAttr ? new Date(deadlineAttr) : defaultDeadline();

      var daysEl = el.querySelector('[data-cd-days]');
      var hoursEl = el.querySelector('[data-cd-hours]');
      var minsEl = el.querySelector('[data-cd-mins]');
      var secsEl = el.querySelector('[data-cd-secs]');

      function tick() {
        var now = new Date().getTime();
        var distance = deadline.getTime() - now;

        if (distance <= 0) {
          setValues(0, 0, 0, 0);
          clearInterval(timer);
          return;
        }

        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var secs = Math.floor((distance % (1000 * 60)) / 1000);

        setValues(days, hours, mins, secs);
      }

      function setValues(d, h, m, s) {
        if (daysEl) daysEl.textContent = pad(d);
        if (hoursEl) hoursEl.textContent = pad(h);
        if (minsEl) minsEl.textContent = pad(m);
        if (secsEl) secsEl.textContent = pad(s);
      }

      function pad(n) {
        return String(n).padStart(2, '0');
      }

      tick();
      var timer = window.setInterval(tick, 1000);
    });
  }

  function defaultDeadline() {
    var d = new Date();
    d.setDate(d.getDate() + 5);
    return d;
  }
})();
