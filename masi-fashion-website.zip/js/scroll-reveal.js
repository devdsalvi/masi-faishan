/**
 * MASI FASHION — SCROLL REVEAL MODULE
 * Reveals any element with [data-reveal] as it enters the viewport,
 * using IntersectionObserver for performance (no scroll-event polling).
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', initScrollReveal);

  function initScrollReveal() {
    var targets = document.querySelectorAll('[data-reveal]');
    if (!targets.length) return;

    // Respect users who prefer reduced motion: show everything immediately.
    var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced || !('IntersectionObserver' in window)) {
      targets.forEach(function (el) {
        el.classList.add('is-visible');
      });
      return;
    }

    var observer = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: '0px 0px -40px 0px'
      }
    );

    targets.forEach(function (el) {
      observer.observe(el);
    });
  }
})();
