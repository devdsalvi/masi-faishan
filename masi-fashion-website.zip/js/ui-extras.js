/**
 * MASI FASHION — UI EXTRAS MODULE
 * Small progressive-enhancement behaviours: footer newsletter sign-up,
 * horizontal product-scroll arrow buttons, wishlist heart toggle.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initNewsletter();
    initScrollNav();
    initWishlist();
  });

  function initNewsletter() {
    var form = document.querySelector('[data-newsletter-form]');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input[type="email"]');
      var note = form.parentElement.querySelector('[data-newsletter-note]');
      if (!input || !input.value.trim()) return;

      if (note) {
        note.textContent = 'Thanks for subscribing! Watch your inbox for exclusive drops.';
      }
      form.reset();
    });
  }

  function initScrollNav() {
    document.querySelectorAll('[data-scroll-target]').forEach(function (nav) {
      var targetId = nav.getAttribute('data-scroll-target');
      var track = document.getElementById(targetId);
      if (!track) return;

      var prevBtn = nav.querySelector('[data-scroll-prev]');
      var nextBtn = nav.querySelector('[data-scroll-next]');
      var scrollAmount = 300;

      if (prevBtn) {
        prevBtn.addEventListener('click', function () {
          track.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });
      }
      if (nextBtn) {
        nextBtn.addEventListener('click', function () {
          track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });
      }
    });
  }

  function initWishlist() {
    document.querySelectorAll('.product-card__wishlist').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var pressed = btn.getAttribute('aria-pressed') === 'true';
        btn.setAttribute('aria-pressed', String(!pressed));
        btn.classList.toggle('is-active', !pressed);
      });
    });
  }
})();
