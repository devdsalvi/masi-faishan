/**
 * MASI FASHION — CORE APP MODULE
 * Handles: logo injection, sticky header, mobile navigation drawer,
 * search overlay, back-to-top button, current-year stamp.
 * Depends on: brand-logo.js (must load before this file)
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    injectLogo();
    setCurrentYear();
    initStickyHeader();
    initMobileNav();
    initSearchOverlay();
    initBackToTop();
    markActiveNavLink();
  }

  /** Inject the base64 brand logo into every [data-brand-logo] <img> */
  function injectLogo() {
    if (typeof MASI_LOGO === 'undefined') return;
    document.querySelectorAll('[data-brand-logo]').forEach(function (img) {
      img.src = MASI_LOGO;
    });
  }

  /** Stamp the current year into [data-year] elements (footer copyright) */
  function setCurrentYear() {
    var year = new Date().getFullYear();
    document.querySelectorAll('[data-year]').forEach(function (el) {
      el.textContent = year;
    });
  }

  /** Add elevation shadow to header once the page scrolls */
  function initStickyHeader() {
    var header = document.querySelector('.site-header');
    if (!header) return;

    var toggleShadow = function () {
      if (window.scrollY > 12) {
        header.classList.add('is-scrolled');
      } else {
        header.classList.remove('is-scrolled');
      }
    };

    toggleShadow();
    window.addEventListener('scroll', toggleShadow, { passive: true });
  }

  /** Mobile navigation drawer open/close */
  function initMobileNav() {
    var toggle = document.querySelector('.nav-toggle');
    var nav = document.querySelector('.main-nav');
    var backdrop = document.querySelector('.nav-backdrop');
    if (!toggle || !nav) return;

    function openNav() {
      nav.classList.add('is-open');
      toggle.classList.add('is-active');
      toggle.setAttribute('aria-expanded', 'true');
      if (backdrop) backdrop.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    }

    function closeNav() {
      nav.classList.remove('is-open');
      toggle.classList.remove('is-active');
      toggle.setAttribute('aria-expanded', 'false');
      if (backdrop) backdrop.classList.remove('is-open');
      document.body.style.overflow = '';
    }

    toggle.addEventListener('click', function () {
      nav.classList.contains('is-open') ? closeNav() : openNav();
    });

    if (backdrop) backdrop.addEventListener('click', closeNav);

    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', closeNav);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeNav();
    });
  }

  /** Search overlay open/close + submit handling */
  function initSearchOverlay() {
    var openBtns = document.querySelectorAll('[data-search-open]');
    var overlay = document.querySelector('.search-overlay');
    if (!overlay) return;

    var closeBtn = overlay.querySelector('.search-panel__close');
    var input = overlay.querySelector('input[type="search"]');
    var form = overlay.querySelector('form');
    var tagButtons = overlay.querySelectorAll('.search-panel__tags button');

    function openSearch() {
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
      window.setTimeout(function () {
        if (input) input.focus();
      }, 150);
      document.body.style.overflow = 'hidden';
    }

    function closeSearch() {
      overlay.classList.remove('is-open');
      overlay.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }

    openBtns.forEach(function (btn) {
      btn.addEventListener('click', openSearch);
    });

    if (closeBtn) closeBtn.addEventListener('click', closeSearch);

    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closeSearch();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeSearch();
    });

    tagButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (input) {
          input.value = btn.textContent.trim();
          input.focus();
        }
      });
    });

    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var query = input ? input.value.trim() : '';
        if (!query) return;
        window.location.href = 'collections.html?search=' + encodeURIComponent(query);
      });
    }
  }

  /** Back-to-top floating button */
  function initBackToTop() {
    var btn = document.querySelector('.back-to-top');
    if (!btn) return;

    window.addEventListener(
      'scroll',
      function () {
        if (window.scrollY > 600) {
          btn.classList.add('is-visible');
        } else {
          btn.classList.remove('is-visible');
        }
      },
      { passive: true }
    );

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /** Mark the nav link matching the current page with aria-current */
  function markActiveNavLink() {
    var current = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-list a').forEach(function (link) {
      var href = link.getAttribute('href');
      if (href === current) {
        link.setAttribute('aria-current', 'page');
      }
    });
  }
})();
