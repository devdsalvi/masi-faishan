/**
 * MASI FASHION — IMAGE LAZY-LOAD ENHANCEMENT
 * Native `loading="lazy"` handles the heavy lifting; this module simply
 * removes the shimmer skeleton class once each image has finished loading,
 * and provides a fallback for browsers without native lazy-load support.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', initLazyLoad);

  function initLazyLoad() {
    var images = document.querySelectorAll('img[loading="lazy"]');

    images.forEach(function (img) {
      if (img.complete && img.naturalWidth > 0) {
        img.classList.add('is-loaded');
      } else {
        img.addEventListener('load', function () {
          img.classList.add('is-loaded');
        });
        img.addEventListener('error', function () {
          img.classList.add('is-loaded');
        });
      }
    });

    // Fallback for very old browsers with no native lazy-load support.
    if (!('loading' in HTMLImageElement.prototype) && 'IntersectionObserver' in window) {
      var lazyObserver = new IntersectionObserver(function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target;
            if (img.dataset.src) img.src = img.dataset.src;
            obs.unobserve(img);
          }
        });
      });
      images.forEach(function (img) {
        lazyObserver.observe(img);
      });
    }
  }
})();
