/**
 * MASI FASHION — CONTACT FORM VALIDATION MODULE
 * Lightweight client-side validation with accessible inline error
 * messaging. No external dependencies; simulates a successful submit
 * since this is a static front-end build (wire up to a real endpoint
 * by replacing the `simulateSubmit` function).
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', initContactForm);

  function initContactForm() {
    var form = document.querySelector('[data-contact-form]');
    if (!form) return;

    var statusEl = form.querySelector('[data-form-status]');

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors(form);

      var isValid = true;
      var name = form.querySelector('#contact-name');
      var email = form.querySelector('#contact-email');
      var phone = form.querySelector('#contact-phone');
      var message = form.querySelector('#contact-message');

      if (!name.value.trim()) {
        showError(name, 'Please enter your full name.');
        isValid = false;
      }

      if (!email.value.trim() || !isValidEmail(email.value.trim())) {
        showError(email, 'Please enter a valid email address.');
        isValid = false;
      }

      if (phone && phone.value.trim() && !isValidPhone(phone.value.trim())) {
        showError(phone, 'Please enter a valid phone number.');
        isValid = false;
      }

      if (!message.value.trim() || message.value.trim().length < 10) {
        showError(message, 'Message should be at least 10 characters.');
        isValid = false;
      }

      if (!isValid) {
        setStatus('Please fix the highlighted fields and try again.', 'error');
        return;
      }

      setStatus('Sending your message…', '');
      simulateSubmit(form, function () {
        setStatus('Thank you! Your message has been sent — our team will reply within 24 hours.', 'success');
        form.reset();
      });
    });

    function setStatus(text, type) {
      if (!statusEl) return;
      statusEl.textContent = text;
      statusEl.className = 'form-status' + (type ? ' ' + type : '');
      statusEl.setAttribute('role', 'status');
    }

    function showError(field, msg) {
      field.setAttribute('aria-invalid', 'true');
      field.style.borderColor = 'var(--masi-red)';
      var errorId = field.id + '-error';
      var existing = document.getElementById(errorId);
      if (!existing) {
        var errorEl = document.createElement('span');
        errorEl.id = errorId;
        errorEl.className = 'form-status error';
        errorEl.style.display = 'block';
        errorEl.style.marginTop = '0.35rem';
        errorEl.textContent = msg;
        field.insertAdjacentElement('afterend', errorEl);
      }
      field.setAttribute('aria-describedby', errorId);
    }

    function clearErrors(scope) {
      scope.querySelectorAll('.form-status.error[id$="-error"]').forEach(function (el) {
        el.remove();
      });
      scope.querySelectorAll('[aria-invalid]').forEach(function (el) {
        el.removeAttribute('aria-invalid');
        el.style.borderColor = '';
      });
    }

    function isValidEmail(value) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    }

    function isValidPhone(value) {
      return /^[0-9+\-\s()]{7,16}$/.test(value);
    }

    function simulateSubmit(formEl, callback) {
      window.setTimeout(callback, 900);
    }
  }
})();
