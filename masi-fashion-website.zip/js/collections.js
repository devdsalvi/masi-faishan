/**
 * MASI FASHION — COLLECTIONS FILTER & SORT MODULE
 * Client-side filtering by category and sorting by price/name for the
 * Collections page product grid. No backend required — operates purely
 * on the DOM nodes already rendered in the page.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', initCollections);

  function initCollections() {
    var grid = document.querySelector('[data-product-grid]');
    if (!grid) return;

    var filterBtns = document.querySelectorAll('[data-collection-filter]');
    var sortSelect = document.querySelector('[data-sort-select]');
    var cards = Array.prototype.slice.call(grid.querySelectorAll('.product-card'));
    var resultsCount = document.querySelector('[data-results-count]');

    // Apply ?search= query param highlighting, if navigated from search
    applySearchParam();

    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var category = btn.getAttribute('data-collection-filter');

        filterBtns.forEach(function (b) {
          b.classList.remove('is-active');
        });
        btn.classList.add('is-active');

        var visibleCount = 0;
        cards.forEach(function (card) {
          var match = category === 'all' || card.getAttribute('data-category') === category;
          card.style.display = match ? '' : 'none';
          if (match) visibleCount++;
        });

        updateCount(visibleCount);
      });
    });

    if (sortSelect) {
      sortSelect.addEventListener('change', function () {
        var value = sortSelect.value;
        var sorted = cards.slice().sort(function (a, b) {
          if (value === 'price-low') {
            return parsePrice(a) - parsePrice(b);
          }
          if (value === 'price-high') {
            return parsePrice(b) - parsePrice(a);
          }
          if (value === 'name') {
            return getTitle(a).localeCompare(getTitle(b));
          }
          return 0; // 'featured' = original order
        });
        sorted.forEach(function (card) {
          grid.appendChild(card);
        });
      });
    }

    function updateCount(n) {
      if (resultsCount) {
        resultsCount.textContent = n + (n === 1 ? ' item' : ' items');
      }
    }

    function parsePrice(card) {
      var priceEl = card.querySelector('.price-now');
      if (!priceEl) return 0;
      return parseFloat(priceEl.textContent.replace(/[^0-9.]/g, '')) || 0;
    }

    function getTitle(card) {
      var titleEl = card.querySelector('.product-card__title');
      return titleEl ? titleEl.textContent.trim() : '';
    }

    function applySearchParam() {
      var params = new URLSearchParams(window.location.search);
      var query = params.get('search');
      var searchNote = document.querySelector('[data-search-note]');
      if (query && searchNote) {
        searchNote.textContent = 'Showing results for “' + query + '”';
        searchNote.hidden = false;
      }
    }

    updateCount(cards.length);
  }
})();
