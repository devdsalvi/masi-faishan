/**
 * MASI FASHION — GALLERY LIGHTBOX + FILTER MODULE
 * Powers the Store Gallery grid: category filtering and a keyboard/touch
 * accessible lightbox viewer with prev/next navigation.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initGalleryFilter();
    initLightbox();
  });

  function initGalleryFilter() {
    var filterBtns = document.querySelectorAll('[data-gallery-filter]');
    var items = document.querySelectorAll('[data-gallery-item]');
    if (!filterBtns.length || !items.length) return;

    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var category = btn.getAttribute('data-gallery-filter');

        filterBtns.forEach(function (b) {
          b.classList.remove('is-active');
          b.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('is-active');
        btn.setAttribute('aria-pressed', 'true');

        items.forEach(function (item) {
          var match = category === 'all' || item.getAttribute('data-gallery-item') === category;
          item.style.display = match ? '' : 'none';
        });
      });
    });
  }

  function initLightbox() {
    var lightbox = document.querySelector('.lightbox');
    if (!lightbox) return;

    var triggers = Array.prototype.slice.call(document.querySelectorAll('[data-lightbox-trigger]'));
    var imgEl = lightbox.querySelector('img');
    var captionEl = lightbox.querySelector('.lightbox__caption');
    var closeBtn = lightbox.querySelector('.lightbox__close');
    var prevBtn = lightbox.querySelector('.lightbox__prev');
    var nextBtn = lightbox.querySelector('.lightbox__next');
    var currentIndex = 0;

    function openLightbox(index) {
      currentIndex = index;
      updateLightbox();
      lightbox.classList.add('is-open');
      lightbox.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      closeBtn.focus();
    }

    function closeLightbox() {
      lightbox.classList.remove('is-open');
      lightbox.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }

    function updateLightbox() {
      var trigger = triggers[currentIndex];
      var fullSrc = trigger.getAttribute('href') || trigger.querySelector('img').src;
      var caption = trigger.getAttribute('data-caption') || '';
      imgEl.src = fullSrc;
      imgEl.alt = caption;
      if (captionEl) captionEl.textContent = caption;
    }

    function showNext() {
      currentIndex = (currentIndex + 1) % triggers.length;
      updateLightbox();
    }

    function showPrev() {
      currentIndex = (currentIndex - 1 + triggers.length) % triggers.length;
      updateLightbox();
    }

    triggers.forEach(function (trigger, index) {
      trigger.addEventListener('click', function (e) {
        e.preventDefault();
        openLightbox(index);
      });
    });

    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    if (nextBtn) nextBtn.addEventListener('click', showNext);
    if (prevBtn) prevBtn.addEventListener('click', showPrev);

    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) closeLightbox();
    });

    document.addEventListener('keydown', function (e) {
      if (!lightbox.classList.contains('is-open')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') showNext();
      if (e.key === 'ArrowLeft') showPrev();
    });
  }
})();
